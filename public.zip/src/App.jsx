import './App.css'
import 'boostrap/dist/css/boostrap.min.css'
import ContenedorLoginRegister from './assets/componentes/ContenedorLoginRegister'
import ContenedorLoginIn from './assets/componentes/ContenedorLoginIn'
import CajaTrasera from './assets/componentes/CajaTrasera'





function App() {

  return (
    <>
    <div className='contenedor__todo'>
        <br></br>
        <ContenedorLoginIn/>
        <br></br>
        <ContenedorLoginRegister />
        <br></br>
        <CajaTrasera/>
    </div>
    </>
  )
}

export default App
