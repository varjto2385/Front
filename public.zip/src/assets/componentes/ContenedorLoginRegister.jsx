
function ContenedorLoginRegister(){
    return (
        <div >
            <div className='contenedor__login-register'>
                <form action="" id = "formulario__login" className="formulario__login">
                    <h2>Registrarse</h2>
                    <input type="text" placeholder="Nombre completo" id="nombre"></input>
                    <input type="text" placeholder="Correo Electronico" id="email"></input>
                    <input type="text" placeholder="Usuario" id="user"></input>
                    <input type="password" placeholder="Contraseña" id="password"></input>
                    <a className="btn1" target="_blank">Regístrarse</a>
                </form>
            
            </div>
        </div>
        
    )
}
export default ContenedorLoginRegister;


