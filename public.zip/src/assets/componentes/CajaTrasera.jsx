function CajaTrasera(){
    return(
        <div>
            <div className="caja__trasera">
                <h3>¿Ya tienes una Cuenta?</h3>
                <p>Inicia sesión para entrar en la Pagina</p>
                <button id="btn__iniciar-sesion">Iniciar sesion</button>
            </div>

            <div className="caja__trasera-register">
                <h3>¿Aun no tienes una Cuenta?</h3>
                <p>Regístrate para que puedas iniciar Sesion</p>
                <button id="btn__registrarse">Regístrarse</button>
            </div>
        </div>
    )
}
export default CajaTrasera;