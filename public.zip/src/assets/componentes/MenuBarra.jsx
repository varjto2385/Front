import 'boostrap/dist/css/boostrap.min.css'

function MenuBarra (){
    return (
        <div>
            <title>Stock Master</title>
            <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/sidebars/"></link>
            <link rel="stylesheet" href="./sass/sidebars.css"></link>
            <link href="./node_modules/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet"></link>
        </div>
    )
}

export default MenuBarra;
