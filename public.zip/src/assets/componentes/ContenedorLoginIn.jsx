import logoimg from '../imagenes/Logo.png'

function ContenedorLoginIn(){
    
    return (
       
        <div>                 
            <div className='contenedor__login-in'>
                <form action="" id = "formulario__login" className="formulario__login">
                    <center><img src={logoimg} width="200" height="152" alt="logo stock" ></img></center>
                    {/*<center><img src='..' width="200" height="152" alt="logo stock" ></img></center>*/}
                     <h2>Iniciar Sesión</h2>
                    <input type="text" placeholder="Correo Electronico" id="email"></input>
                    <input type="password" placeholder="Contraseña" id="password"></input>
                    <a className="btn1"  href="./menu.html" target="_blank">Ingresar</a>
                </form>
            </div> 
        </div>
        
    )
}
export default ContenedorLoginIn;